# Banco Python

Uma biblioteca Python para gerenciar contas bancárias.

## Instalação

Você pode instalar a biblioteca usando pip:

```bash
pip install banco_python